#ifndef PROGRAM_H
#define PROGRAM_H

//Required includes for Gui
#include "raylib.h"
#include "screenSizeTransfer.h"
#include <memory>
#include "GuiEnum.h"
#include "mouse.h"
#include "menu.h"
#include "startMenu.h"
#include "generalSettingsMenu.h"
#include "multiplayerMenu.h"

class Program
{
    private:
        //Gui Stuff
        bool end;
        bool debug;
        std::unique_ptr<Menu> currentMenu;
        MenuChoice menuType;
    public:
        Program();
        void loop();
        void close();
    private:
        void updateLogic(GuiEvent state);
};

#endif