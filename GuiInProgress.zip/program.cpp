#include "program.h"


Program::Program()
{
    //Required for GUI
    InitWindow(sst::baseX, sst::baseY, "Game");
    SetTargetFPS(60);
    end = false;
    SetExitKey(KEY_NULL); //Removes escape as the exit key
    debug = false;
    //Initializes starting menu
    currentMenu = std::make_unique<StartMenu>();


}

void Program::close()
{
    CloseWindow(); //Closes the window
}

void Program::loop()
{

        
    while(!end)
    {
        
        if (IsKeyPressed(KEY_ESCAPE)) //For testing purposes
            end = true;
        
        if (IsKeyPressed(KEY_P))
            debug = !debug;
        
        BeginDrawing();

            ClearBackground(RAYWHITE);

            currentMenu->draw();
            if (debug)
                currentMenu->drawDebug();

        EndDrawing();
        //Compute new state for menu
        updateLogic(currentMenu->updateMenuLogic());
    }
}

void Program::updateLogic(GuiEvent state)
{
    switch(state)
    {
        case Nothing:
            break;
        case Exit:
            end = true;
            break;
        case OpenGeneralSettings:
            this->currentMenu = std::make_unique<GeneralSettingsMenu>();
            break;
        case OpenStartingMenu:
            this->currentMenu = std::make_unique<StartMenu>();
            break;
        case OpenMultiplayerMenu:
            this->currentMenu = std::make_unique<MultiplayerMenu>();
            break;
        case screenSizeTo480p:
            SetWindowSize(854, 480);
            SetWindowPosition(GetMonitorWidth(0)/2 - 854/2, GetMonitorHeight(0)/2 - 480/2); 
            this->currentMenu = std::make_unique<GeneralSettingsMenu>(); 
            break;
        case screenSizeTo720p:
            SetWindowSize(1280, 720);
            SetWindowPosition(GetMonitorWidth(0)/2 - 1280/2, GetMonitorHeight(0)/2 - 720/2); 
            this->currentMenu = std::make_unique<GeneralSettingsMenu>(); 
            break;
        case screenSizeTo1080p:
            SetWindowSize(1920, 1080);
            SetWindowPosition(GetMonitorWidth(0)/2 - 1920/2, GetMonitorHeight(0)/2 - 1080/2);
            this->currentMenu = std::make_unique<GeneralSettingsMenu>(); 
            break;
            break;
        case screenSizeTo1440p:
            
            break;
        case screenSizeTo3840p:
            
            break;
        
    }
}
