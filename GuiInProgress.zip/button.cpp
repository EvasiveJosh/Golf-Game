#include "button.h"

Rectangle Button::labelBounds(const std::string& text, int font, int posX, int posY)
{
    float rectX = sst::cx(posX);
    float rectY = sst::cy(posY);
    float width = MeasureText(text.c_str(), sst::cx(font));
    Rectangle rec = {rectX, rectY, width, (float)sst::cy(font)};
    return rec;
}

Button::Button(const std::string& text, int font, int posX, int posY)
{
    label = text;
    bounds = labelBounds(text, font, posX, posY);
}

bool Button::isHovered(const Mouse& mouse) const
{
    return CheckCollisionRecs(mouse.mouseHitbox(), bounds);
}

const std::string& Button::getLabel() const
{
    return label;
}

const Rectangle& Button::getBounds() const
{
    return bounds;
}
