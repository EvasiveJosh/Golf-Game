#include "Menu.h"

void Menu::addButton(const std::string& label, int font, int posX, int posY)
{
    buttons.push_back(Button(label, font, posX, posY));
}

int Menu::amountOfButtons() const
{
    return buttons.size();
}

const Button& Menu::getButton(std::string& label)
{
    if (buttons.size() == 0)
        throw std::runtime_error("No buttons available in the menu");
    
    for(int i = 0; i < buttons.size(); i++)
    {
        if (label.compare(buttons[i].getLabel()) == 0)
            return buttons[i];
    }
    throw std::runtime_error("No such button exists");
}

int Menu::centerTextX(const std::string& text, int font)
{
    return (t::baseX/2) - (MeasureText(text.c_str(), (font))/2);
}

Rectangle Menu::surroundTextPad(const std::string& text, int font, int posX, int posY)
{
    float rectX = t::cx(posX);
    float rectY = t::cy(posY);
    float width = MeasureText(text.c_str(), t::cx(font));
    Rectangle rec = {rectX - 10, rectY - 10, width + 10, (float)t::cy(font) + 10};
    return rec;
}

int Menu::buttonClicked() const
{
    for(int i = 0; i < buttons.size(); i++)
    {
        if (buttons[i].isHovered(mouse))
            return i;
    }
    return -1;
}

