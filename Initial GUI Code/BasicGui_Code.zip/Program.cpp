#include "Program.h"

Program::Program()
{
    InitWindow(1280, 720, "Game");
    //InitWindow(1920, 1080, "Game");
    SetTargetFPS(60);
    gui = Gui(StartingMenu);
    end = false;
    SetExitKey(KEY_NULL); //Removes escape as the exit key
    debug = false;
}

void Program::close()
{
    CloseWindow(); //Closes the window
}

void Program::loop()
{

        
    while(!end && !gui.getRidOfMe())
    {
        
        if (IsKeyPressed(KEY_ESCAPE))
            end = true;
        
        if (IsKeyPressed(KEY_P))
            debug = !debug;
        
        BeginDrawing();

            ClearBackground(RAYWHITE);

            gui.drawMenu();
            if (debug)
                gui.drawDebugView();

        EndDrawing();

        //Gui what you got for me
        gui.computeNewState();
    }
}
