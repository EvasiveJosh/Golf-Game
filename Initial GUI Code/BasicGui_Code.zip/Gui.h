#ifndef GUI_H
#define GUI_H

#include <memory>
#include "Menu.h"
#include "GuiEnum.h"
#include <iostream>

/*
- Grey out buttons that can't be pressed
- Bring if statements for pointer check into the constructor and the set function
- TODO - Move loadMenu() into setCurrentMenu (nuking appropriate program.h code)
- TODO - Figure out return value of computeNewState
*/

class Gui
{
    private:
        std::unique_ptr<Menu> currentMenu;
        MenuChoice menuType;
        bool exit;
    public:
        Gui() = default; //Will set it to null pointer
        Gui(MenuChoice menuType);
        //Changes currentMenu during runtime
        void setCurrentMenu(MenuChoice newMenu);
        //Draws the menu
        void drawMenu() const;
        //Draws debug menu
        void drawDebugView() const;
        //Runs necessary logic code
        void computeNewState();
        //Returns exit
        bool getRidOfMe() const;

};

#endif
