#ifndef GUIENUM_H
#define GUIENUM_H

enum MenuChoice
{
    StartingMenu,
    SingleplayerSettings,
    MultiplayerSettings,
    GeneralSettings
};

enum GuiEvent
{
    Nothing,
    Exit
};

#endif