#include "Button.h"

Rectangle Button::labelBounds(const std::string& text, int font, int posX, int posY)
{
    float rectX = t::cx(posX);
    float rectY = t::cy(posY);
    float width = MeasureText(text.c_str(), t::cx(font));
    Rectangle rec = {rectX, rectY, width, (float)t::cy(font)};
    return rec;
}

Button::Button(const std::string& text, int font, int posX, int posY)
{
    label = text;
    bounds = labelBounds(text, font, posX, posY);
}

bool Button::isHovered(const Mouse& mouse) const
{
    return CheckCollisionRecs(mouse.mouseHitbox(), bounds);
}

const std::string& Button::getLabel() const
{
    return label;
}

const Rectangle& Button::getBounds() const
{
    return bounds;
}
