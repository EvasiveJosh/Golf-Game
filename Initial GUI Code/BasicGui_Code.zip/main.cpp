#include <iostream>
#include "Program.h"

int main()
{
    Program program;
    program.loop();
    program.close();
    return 0;
}