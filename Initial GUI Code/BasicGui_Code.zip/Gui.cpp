#include "Gui.h"
#include <utility>
#include "StartMenu.h"

Gui::Gui(MenuChoice menuType) 
{
    exit = false;
    setCurrentMenu(menuType);
}

void Gui::setCurrentMenu(MenuChoice newMenu)
{
    menuType = newMenu;
    //Loads menu and performs one time load
    switch (menuType)
    {
        case StartingMenu:
            this->currentMenu = std::make_unique<StartMenu>();
            break;
        case SingleplayerSettings:
            break;
        case MultiplayerSettings:
            break;
        case GeneralSettings:
            break;
        default:
            throw std::runtime_error("Invalid Menu");
    }
}


void Gui::drawMenu() const
{
    if (currentMenu)
    {
        currentMenu->draw();
    } 
    else 
    {
        throw std::runtime_error("No menu");
    }
}

void Gui::drawDebugView() const
{
    if (currentMenu)
    {
        currentMenu->drawDebug();
    }  
    else 
    {
        throw std::runtime_error("No menu");
    }
}

void Gui::computeNewState()
{
    GuiEvent event = currentMenu->updateMenuLogic();
    switch (event)
    {
        case Nothing:
            break;
        case Exit:
            exit = true;
            break;
    }
}

bool Gui::getRidOfMe() const
{
    return exit;
}