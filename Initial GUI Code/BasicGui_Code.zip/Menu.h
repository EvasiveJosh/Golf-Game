#ifndef MENU_H
#define MENU_H

#include "raylib.h"
#include "Mouse.h"
#include "Button.h"
#include "TextureClass.h"
#include <vector>
#include <string>
#include <stdexcept>
#include "CoordinateTransfer.h"
#include "GuiEnum.h"

/*
Notes:
- Constructor must initialize screen variables and call the buttons constructor
- load function must intialize textures, mouse, buttons and isLoaded
- FIX center_y
*/

/*
TODO:
- Change beforeDraw and drawDebug to have part of those done by default in Menu class
*/

class Menu
{
    protected:
        TextureClass textures;
        Mouse mouse;
        std::vector<Button> buttons;
    public:
        virtual ~Menu() = default;
        //Handles displaying
        virtual void draw() = 0;
        //Does any necessary operations before drawing (needs to update mouse position)
        virtual GuiEvent updateMenuLogic() = 0;
        //Draws the mouse and buttons hitboxes to the screen.
        virtual void drawDebug() = 0;

        void addButton(const std::string& label, int font, int posX, int posY);
        int amountOfButtons() const;
        const Button& getButton(std::string& label);
        //Only be used after using IsKeyPressed function
        int buttonClicked() const;

        //Utility functions for menus (base coordinates of the CoordinateTransfer mapping are used)
        //Returns the x position that centers the text on the screen in the original ratio (1280 x 720)
        int centerTextX(const std::string& text, int font);
        //Returns a rectangle that surrounds the text with some padding
        Rectangle surroundTextPad(const std::string& text, int font, int posX, int posY);
};

#endif